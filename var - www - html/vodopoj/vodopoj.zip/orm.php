<?php

require_once __DIR__ . '/ORM.php';
$orm = new ORM('localhost', 'phpmyadmin', 'Jyie-ha0r-kgie', 'vodopoi');