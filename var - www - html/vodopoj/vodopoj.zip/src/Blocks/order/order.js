//$(document).ready(() => {
//   const pref = '.order'; // prefix for current folder
//   
//   $(pref+'')
//});