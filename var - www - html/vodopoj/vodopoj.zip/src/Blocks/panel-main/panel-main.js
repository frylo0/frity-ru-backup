//$(document).ready(() => {
//   const pref = '.panel-main'; // prefix for current folder
//   
//   $(pref+'')
//});