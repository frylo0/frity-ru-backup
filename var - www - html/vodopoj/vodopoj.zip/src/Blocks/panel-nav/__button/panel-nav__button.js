//$(document).ready(() => {
//   const pref = '.panel-nav__button'; // prefix for current folder
//   
//   $(pref+'')
//});