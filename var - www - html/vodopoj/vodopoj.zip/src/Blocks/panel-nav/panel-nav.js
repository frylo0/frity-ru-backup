import './__button/panel-nav__button';
//$(document).ready(() => {
//   const pref = '.panel-nav'; // prefix for current folder
//   
//   $(pref+'')
//});