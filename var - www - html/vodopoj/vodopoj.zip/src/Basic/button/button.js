//$(document).ready(() => {
//   const pref = '.button'; // prefix for current folder
//   
//   $(pref+'')
//});