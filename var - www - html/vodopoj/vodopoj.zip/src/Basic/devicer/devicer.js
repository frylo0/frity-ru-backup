//$(document).ready(() => {
//   const pref = '.devicer'; // prefix for current folder
//   
//   $(pref+'')
//});