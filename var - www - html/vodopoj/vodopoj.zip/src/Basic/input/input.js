//$(document).ready(() => {
//   const pref = '.input'; // prefix for current folder
//   
//   $(pref+'')
//});