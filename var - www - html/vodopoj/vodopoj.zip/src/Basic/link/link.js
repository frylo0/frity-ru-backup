//$(document).ready(() => {
//   const pref = '.link'; // prefix for current folder
//   
//   $(pref+'')
//});