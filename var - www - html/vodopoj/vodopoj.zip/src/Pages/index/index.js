import './../../bundle';

// Code libs and plugins
import { globalEventone } from '../../Plugins/eventone.js';

globalEventone();