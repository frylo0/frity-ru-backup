<?php
$mysql_connection_info = [
  'host' => 'localhost',
  'username' => 'phpMyAdminUser',
  'password' => 'basketball-sport',
  'dbname' => '100kpd'
];
