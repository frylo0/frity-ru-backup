chrome.runtime.onMessage.addListener(
   (request, sender, sendResponse) => {
      onMessage(request, sender)
         .then(sendResponse)
         .catch(err => sendResponse({type: 'error', error: err}));
      
      return true; // return true to indicate you want to send a response asynchronously
   }
);

async function onMessage(request, sender) {
   if (request.key == 'task') {
      let testData = await new Promise((resolve) => chrome.storage.local.get('test', function (res) {
         resolve(res);
      }));
      let roomData = await new Promise((resolve) => chrome.storage.local.get('room', function (res) {
         resolve(res);
      }));

      //alert(sender.tab.url + '\n' + request.task + request.answers);
      let task = request.task;
      console.log(request);

      const host = 'https://frity.ru/pycpp/php/ext/';
      try {
         let answer = await fetch(host + 'get-answer-selected.php', {
            method: 'POST',
            mode: 'no-cors',
            headers: {
               'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: Object.entries({
               task: task,
               testId: testData.test.id,
               roomId: roomData.room.id,
            }).map(([key, val]) => `${key}=${val}`).join('&'),
         }).then(r => r.text());

         return { type: 'response', answer: answer };
      }
      catch (err) {
         console.error(err);
         return { type: 'error', error: err };
      }
   }
}

// Fix service worker inactive
chrome.runtime.onConnect.addListener(port => {
   if (port.name !== 'foo') return;
   port.onMessage.addListener(onMessage);
   port.onDisconnect.addListener(deleteTimer);
   port._timer = setTimeout(forceReconnect, 250e3, port);
});
function forceReconnect(port) {
   deleteTimer(port);
   port.disconnect();
}
function deleteTimer(port) {
   if (port._timer) {
      clearTimeout(port._timer);
      delete port._timer;
   }
}