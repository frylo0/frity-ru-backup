function main() {
   window.addEventListener("keyup", e => {
      if ((e.key === 'c' || e.key === 'с') && e.ctrlKey === true) { // ctrl + c : one c is eng other russian
         const selectedText = getSelectionText();

         forwardTask(selectedText, response => {
            const answer = JSON.parse(decodeURI(response.answer));
            console.log("Answer: ", answer);
            
            showAnswer(answer);
         });
      }
   });

   createAnswer();
}


// Force establishing connection, fix of inactive service worker
let port;
function connect() {
   port = chrome.runtime.connect({ name: 'foo' });
   port.onDisconnect.addListener(connect);
   port.onMessage.addListener(msg => {
      console.log('received', msg, 'from bg');
   });
}
connect();


function forwardTask(task, onSuccess) {
   chrome.runtime.sendMessage({ key: 'task', task: encodeURIComponent(task) }, onSuccess);
}


function createAnswer() {
   const answerWrapper = document.createElement('div');
   answerWrapper.innerHTML = `
      <div class="pycpp_answer" style="
         position: fixed; right: 0; bottom: 0; max-width: 50vw;
         display: none; z-index: 10000;
         background: white; padding: 1em; font-family: monospace;
      ">
         <div class="pycpp_answer__title" style="
            font-weight: bold;
         "></div>
         <div class="pycpp_answer__show-description-button" style="
            font-style: italic; font-size: 0.75em; line-height: 1em; margin-top: 0.25rem; cursor: pointer;
         ">Описание</div>
         <div class="pycpp_answer__description" style="
            font-style: italic; font-size: 0.75em; line-height: 1em; margin-top: 0.25rem; display: none;
         "></div>
         <div class="pycpp_answer__controls" style="
            font-size: 0.75em; color: grey; margin-top: 0.25rem;
         ">
            <span class="pycpp_answer__close-button" style="
               cursor: pointer;
            ">Закрыть</span>
            <span class="pycpp_answer__toggle-side-button" title="Прилипнуть к другому краю экрана" style="
               cursor: pointer;
            ">Сторона</span>
         </div>
      </div>
   `;

   const answer = window.pycpp_answer = answerWrapper.firstElementChild;
   document.body.append(answer);
   
   const description = answer.querySelector('.pycpp_answer__description');

   const buttonClose = answer.querySelector('.pycpp_answer__close-button');
   buttonClose.addEventListener('click', () => answer.hide());
   const buttonToggleSide = answer.querySelector('.pycpp_answer__toggle-side-button');
   buttonToggleSide.addEventListener('click', () => answer.changeSide());
   const buttonShowDescription = answer.querySelector('.pycpp_answer__show-description-button');
   buttonShowDescription.addEventListener('click', () => {
      description.style.display = '';
      buttonShowDescription.style.display = 'none';
   });
   
   onClickOutside(answer, () => answer.hide());
   
   answer.setTitle = value => {
      answer.querySelector('.pycpp_answer__title').innerHTML = value;
   };
   answer.setDescription = value => {
      answer.querySelector('.pycpp_answer__description').innerHTML = value;
   };
   answer.show = () => {
      answer.style.display = '';
      description.style.display = 'none';
      buttonShowDescription.style.display = '';
   };
   answer.hide = () => {
      answer.style.display = 'none';
   };
   answer.changeSide = () => {
      if (answer.style.right === '0px') {
         answer.style.right = ''; answer.style.left = '0px';
      } else {
         answer.style.left = ''; answer.style.right = '0px';
      }
   };
}

function showAnswer(answer) {
   window.pycpp_answer.setTitle(answer.value);
   window.pycpp_answer.setDescription(answer.description);
   window.pycpp_answer.show();
}


function getSelectionHtml() {
   var html = "";
   if (typeof window.getSelection != "undefined") {
      var sel = window.getSelection();
      if (sel.rangeCount) {
         var container = document.createElement("div");
         for (var i = 0, len = sel.rangeCount; i < len; ++i) {
            container.appendChild(sel.getRangeAt(i).cloneContents());
         }
         html = container.innerHTML;
      }
   } else if (typeof document.selection != "undefined") {
      if (document.selection.type == "Text") {
         html = document.selection.createRange().htmlText;
      }
   }
   return html;
}

function getSelectionText() {
   const html = getSelectionHtml();
   const div = document.createElement('div');
   div.innerHTML = html;
   return div.textContent;
}

function onClickOutside(el, onEvent) {
   window.addEventListener('click', function (e) {
      if (el.contains(e.target)) {
         // Clicked in box
      } else {
         onEvent(e);
      }
   });
}

main();