$ANSWER.removeButton.click(action('click: remove answer button'));
$ANSWER.likeButton.click(action('click: like answer button'));
$ANSWER.variants.click(action('click: variant answer label'));