$('.new-answer-button').click(action('click: new answer button', e => {
   $ANSWER.new.removeClass('dn');
}));
