<script src="<?= $root ?>/js/eventone.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="<?= $root ?>/js/masonry.min.js"></script>

<script src="<?= $root ?>/index.js?ver=<?= $VER ?>"></script>

<script src="<?= $root ?>/js/task/init.js?ver=<?= $VER ?>"></script>
<script src="<?= $root ?>/js/task/action.js?ver=<?= $VER ?>"></script>
<script src="<?= $root ?>/js/task/handler.js?ver=<?= $VER ?>"></script>

<script src="<?= $root ?>/js/answer/init.js?ver=<?= $VER ?>"></script>
<script src="<?= $root ?>/js/answer/action.js?ver=<?= $VER ?>"></script>
<script src="<?= $root ?>/js/answer/handler.js?ver=<?= $VER ?>"></script>

<script src="<?= $root ?>/js/new/test.js?ver=<?= $VER ?>"></script>
<script src="<?= $root ?>/js/new/task.js?ver=<?= $VER ?>"></script>
<script src="<?= $root ?>/js/new/answer.js?ver=<?= $VER ?>"></script>

<script src="<?= $root ?>/js/search.js?ver=<?= $VER ?>"></script>
</body>

</html>