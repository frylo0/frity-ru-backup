   <?php
   require_once './../db.php';
   require_once './../api.php';

   php_root('./..');

   $page_title = 'Комнаты | PyCPP';
   require_once $php_root . '/head.php';
   ?>

   <?php if (!array_key_exists('id', $_GET)) : ?>

      <h1>Список комнат</h1>
      <input type="text" id="roomSearch" placeholder="Введите номер вашей комнаты" /><br>
      <div style="display: flex; flex-direction: column;">
         <script>
            roomSearch.addEventListener('keyup', e => {
               document.querySelectorAll('a').forEach(a => {
                  a.style.overflow = 'hidden';
                  a.style.display = (a.textContent.trim().startsWith(e.target.value) ? '' : 'none');
                  a.style.height = (a.textContent.trim().startsWith(e.target.value) ? '' : '0px');
               });
            });
         </script>

         <?php

         $rooms = task('SELECT id_room, room_name FROM pycpp_room')->fetch_all(MYSQLI_ASSOC);
         foreach ($rooms as $room) {
            echo "<a href=\"./?id={$room['id_room']}&name={$room['room_name']}\">{$room['room_name']}</a>";
         }
         ?>
      </div>

   <?php else : ?>

      <h1>Комната: <?= $_GET['name'] ?></h1>

      <?php
      require './../task/Task.php';
      $room = task("SELECT * FROM pycpp_room WHERE id_room='{$_GET['id']}'")->fetch_assoc();

      $answers = $room['room_id_task'];
      $answers = explode(',', $answers);

      foreach ($answers as $answer) {
         if ($answer) {
            $task = new Task($answer);
            echo $task->block();
         } else {
            echo 'Нет данных в комнате';
         }
      }
      ?>

   <?php endif; ?>

   <?php require_once $php_root . '/foot.php'; ?>